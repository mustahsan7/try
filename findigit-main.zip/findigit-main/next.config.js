const nextTranslate = require('next-translate-plugin');

module.exports = nextTranslate();
